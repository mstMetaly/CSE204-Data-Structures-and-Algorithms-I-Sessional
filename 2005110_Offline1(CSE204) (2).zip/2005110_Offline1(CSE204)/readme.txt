List.cpp -----Template List Class
ArrayImplementation.cpp----List class implemented by array
LLImplementation.cpp-------List class implemented by linked list
Main.cpp------Main for both ArrayImplementation.cpp and LLImplementation.cpp

To  Run---comment out proper mylist which i indicated by comment in' main ' of Main.cpp


LRUCacheImplementation.cpp------LRUCacheImplementation has its own main,tried to solve but i got stuck,somehow it creates gurbage value,i couldn;t solve it.