#include<iostream>
#include "List.cpp"
using namespace std;

template<class E>
class Node{

public:
    E value;
    Node* next;

    Node()
    {
        next=NULL;
    }

    Node(E value,Node* next)
    {
        this->value=value;
        this->next=next;
    }


    Node(Node* next)
    {
        this->next=next;
    }

    Node(Node &ob)
    {
        value=ob.value;
        next=ob.next;

    }



};

template<class E>
class MyList: public List<E>
{
private:
    Node<E>* head;
    Node<E>* tail;
    Node<E>* curr;
    int sizeOfList=0;

public:
    MyList()
    {
      curr=head=tail=NULL;
       sizeOfList=0;
    }
    MyList(int K)
    {
     curr=head=tail=NULL;
     sizeOfList=0;
    }

    MyList(MyList &ob)
    {
       head=ob.head;
       tail=ob.tail;
       curr=ob.curr;
       sizeOfList=ob.sizeOfList;


    }



    ~MyList()
    {
        while(head!=NULL){
           curr=head;
           head=head->next;
           delete[] curr;

        }
    }



    int Size()
    {
    return sizeOfList;
    }



    void push(E value)
    {

       Node<E>* item=new Node<E>(value,NULL);
      // cout << "tail:"<< tail->value<< endl;

        if(curr==head && curr==NULL && head==NULL)
        {
           /// cout << "lopp1"<< endl;
           item->next=curr;
           head=item;
           curr=item;
           tail=item;
          /// cout << "tail:"<< tail->value<< endl;
           /// cout << "head:"<< head->value<< endl;
        }


       // cout << "test"<< endl;
       else if(curr==head && curr!=NULL)
        { /// cout << "lopp2"<< endl;
            item->next=curr;
           head=item;
           curr=item;
          /// cout << "tail:"<< tail->value<< endl;
          /// cout << "head:"<< head->value<< endl;
        }

       else if(curr!=head )
        {
          /// cout << "lopp3"<< endl;
           Node<E>* prev=head;
           while(prev->next!=curr)
           {
               prev=prev->next;
           }
            prev->next=item;
            item->next=curr;
            curr=item;
          ///  cout << "tail:"<< tail->value<< endl;
           /// cout << "head:"<< head->value<< endl;

        }

      //  cout << "tail:"<< tail->value<< endl;
        sizeOfList++;


    }


     void pushBack(E value)
     {

     Node<E>* item;
     item=new Node<E>(value,NULL);
     if(head==NULL && tail==NULL){
        head=item;
        tail=head;
        curr=head;
     }
     else{
     tail->next=item;
     tail=item;
     }
     sizeOfList++;

     }

     E erase()
     {
       /* E temp=curr->value;
        Node<E>* tempNode=curr;
        Node<E>* tempNode2=head;
        if(curr->next==NULL)
        {
           while(tempNode2->next->next!=NULL)
           {
               tempNode2=tempNode2->next;
           }
           curr=tempNode2;
           curr->next=NULL;
           delete[] curr->next;
           sizeOfList--;
        }
        else{

           while(curr->next->next!=NULL)
           {
               curr->value=curr->next->value;
               curr=curr->next;
           }
           curr->value=curr->next->value;
           curr->next=NULL;
           sizeOfList--;
           curr=tempNode;
        }


        return temp;*/

        E val=curr->value;
        Node<E> * temp=curr;

        if(curr==head && curr->next!=NULL )
        {

           Node<E> *temp2=head;
           head=head->next;
           curr=head;
          // delete[] temp2;
          ///cout << "head:"<< head->value<< endl;
         /// cout << "tail:"<< tail->value<< endl;
        }


        else if(curr==tail){

             Node<E>* temp2=curr;
             Node<E>* prev=head;
             while(prev->next!=curr)
             {
               prev=prev->next;
             }
             curr=prev;
             curr->next=NULL;
             tail=curr;
            // delete[] temp2;
                     /// cout << "head:"<< head->value<< endl;
         /// cout << "tail:"<< tail->value<< endl;


        }

        else{

             Node<E>* temp2=curr;
             Node<E>* prev=head;
             while(prev->next!=curr)
             {
               prev=prev->next;
             }

            prev->next=curr->next;
            curr=prev->next;
           // delete[] temp2;
                    /// cout << "head:"<< head->value<< endl;
         /// cout << "tail:"<< tail->value<< endl;

        }

        sizeOfList--;
        return val;

     }




     void setToBegin()
     {
         curr=head;
     }

     void setToEnd()
     {

        while(curr->next!=NULL)
        {
            curr = curr->next;
        }
         /// cout << "head:"<< head->value<< endl;
         /// cout << "tail:"<< tail->value<< endl;


     }


     void prev() {

       if(curr==head) curr=NULL;
       else{
       Node<E>* temp=head;
       while(temp->next!=curr)
          {
             temp=temp->next;
          }
       curr=temp;
       }
    }



      void next()
       {
       if(curr==NULL | curr->next==NULL)
       {
         cout <<"Empty"<< endl;
       }
       else
        curr=curr->next;
    }


    int currPos() {
        Node<E> *temp = head;
        int i = 0;
        while (temp != curr)
        {
             i++;
            temp = temp->next;

        }
        return i;
    }


     void setToPos(int pos)
      {
        curr = head;
        for(int i = 0; i<pos; i++){
            curr = curr->next;
        }
    }


     E getValue() {
        return curr->value;
    }


    int find(E item) {
       Node<E>* temp=head;
       int index=-1,i=0;
       while (temp!=NULL)
       {
           if(temp->value==item) index=i;
           temp=temp->next;
           i++;
       }

        return index;
    }



    void clear() {
       sizeOfList=0;
      head=tail=curr=NULL;
    }



    void print()
    {

     Node<E>* temp=head;
     for(int i=0;i<sizeOfList;i++)
     {
         if(i==0)
            cout << "<";
         if(temp==curr)
            cout << "|";
         cout<< temp->value << " ";
         if(i==(sizeOfList-1))
            cout<< ">";
         temp=temp->next;
     }

     cout << endl;


    }


};
