#include<stdio.h>
#include<bits/stdc++.h>
#include "LLImplementation.cpp"


class Pair{
    int key;
    int val;

public:
    int getKey()
    {
     return key;
    }

    int getValue()
    {
        return val;
    }

    void setKey(int value)
    {
        key=value;
    }

     void setValue(int value)
    {
        val=value;
    }


    Pair()
    {

    }
    Pair(int x,int y)
    {
        key=x;
        val=y;
    }

    Pair* operator=(Pair& ob)
    {
        this->setKey(ob.getKey());
        setValue(ob.getValue());
        return this;

    }

    bool operator==( Pair& ob)
    {
        if(getKey()==ob.getKey() && getValue()==ob.getValue())return true;
        else return false;

    }





  friend  ostream& operator<< (ostream& ob,const Pair& ob2);

};

ostream& operator<< (ostream& ob, Pair& ob2)
{
        ob<< ob2.getKey()<< ","<< ob2.getValue();
        return ob;

}


class LRUCache{
      int capacity;
  public:
    MyList<Pair> mylist;
    LRUCache(int capacity)
    {
        this->capacity=capacity;
    }

    LRUCache()
    {
        capacity=0;
    }


    void put(int x,int y)
    {
        Pair ob(x,y);
        mylist.push(ob);
    }


    void printLRU()
    {
        mylist.print();
    }

};


int main()
{
   // MyList<Pair> lruList;
   // Pair ob(1,1);
    //lruList.push(ob);
    //lruList.print();

  // cout << lruList.Size()<< endl;
  // cout <<lruList.getValue().getX();






 // LRUCache lruList(2);
 // lruList.put(1,1);
//  lruList.printLRU();

    MyList<int> mylist(2);
    mylist.push(1);
    mylist.push(2);
    mylist.push(3);
    mylist.push(4);
    mylist.print();
    mylist.erase();
    mylist.print();
    mylist.erase();
    mylist.print();







}
